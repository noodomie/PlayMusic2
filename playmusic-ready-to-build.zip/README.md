# PlayMusic

PlayMusic is a **client-side Fabric mod for Minecraft 1.20.1**. Press **O** to open the menu.

## Features

- YouTube URL input
- Play / Stop button
- Loop ON / OFF
- Music continues while the menu is closed
- Works in singleplayer and multiplayer because the mod runs only on the physical client
- Simple English UI

## Audio backend

Minecraft 1.20.1 does not natively decode arbitrary YouTube audio streams. PlayMusic therefore uses two external command-line tools:

- `yt-dlp` to fetch the audio from the supplied YouTube URL
- `FFmpeg` to convert the audio to WAV

The mod writes the temporary WAV file under the Fabric config directory and deletes it after playback.

## Installing yt-dlp and FFmpeg

Put executable files in either of these locations:

1. Add them to the operating system `PATH`, or
2. Place them in `.minecraft/playmusic/bin/` as `yt-dlp` / `yt-dlp.exe` and `ffmpeg` / `ffmpeg.exe`, or
3. Set `yt_dlp_path=` and `ffmpeg_path=` in `.minecraft/config/playmusic.properties`.

Example config:

```properties
yt_dlp_path=C:/tools/yt-dlp.exe
ffmpeg_path=C:/tools/ffmpeg.exe
```

## Build

Use Java 17 and run:

```text
./gradlew build
```

The built mod will be in `build/libs/`.

## Important

This project is intentionally client-only. Do not install it on a dedicated server.

Use YouTube content in accordance with YouTube's terms and the rights attached to the content you play.

## GitHub Actions build

This repository includes `.github/workflows/build.yml`. GitHub Actions builds the Fabric 1.20.1 mod with Java 17 and publishes the compiled `playmusic-1.0.0.jar` as an Actions artifact.
