package com.playmusic.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class MusicScreen extends Screen {
    private TextFieldWidget urlField;
    private ButtonWidget playStopButton;
    private ButtonWidget loopButton;

    private static final int CARD_W = 460;
    private static final int CARD_H = 220;

    public MusicScreen() {
        super(Text.literal("PlayMusic"));
    }

    @Override
    protected void init() {
        int left = (this.width - CARD_W) / 2;
        int top = (this.height - CARD_H) / 2;

        this.urlField = new TextFieldWidget(this.textRenderer, left + 30, top + 70, CARD_W - 60, 20,
                Text.literal("YouTube URL"));
        this.urlField.setMaxLength(2048);
        this.urlField.setPlaceholder(Text.literal("https://www.youtube.com/watch?v=..."));
        this.addSelectableChild(this.urlField);

        this.playStopButton = ButtonWidget.builder(Text.literal("Play"), button -> onPlayStop())
                .dimensions(left + 30, top + 115, 215, 24)
                .build();
        this.addDrawableChild(this.playStopButton);

        this.loopButton = ButtonWidget.builder(Text.literal("Loop: OFF"), button -> {
                    PlayMusicClient.MUSIC_PLAYER.setLoop(!PlayMusicClient.MUSIC_PLAYER.isLoopEnabled());
                    updateButtons();
                })
                .dimensions(left + 255, top + 115, 175, 24)
                .build();
        this.addDrawableChild(this.loopButton);

        ButtonWidget closeButton = ButtonWidget.builder(Text.literal("Close"), button -> this.close())
                .dimensions(left + 30, top + 157, CARD_W - 60, 20)
                .build();
        this.addDrawableChild(closeButton);

        this.urlField.setFocused(true);
        updateButtons();
    }

    private void onPlayStop() {
        MusicPlayer player = PlayMusicClient.MUSIC_PLAYER;
        if (player.isPlaying()) {
            player.stop();
            updateButtons();
            return;
        }

        String url = this.urlField.getText().trim();
        if (!isYouTubeUrl(url)) {
            player.stop();
            PlayMusicClient.showError("Enter a valid YouTube URL.");
            return;
        }

        player.start(url);
        updateButtons();
    }

    private static boolean isYouTubeUrl(String url) {
        if (url == null || url.isBlank()) return false;
        try {
            java.net.URI uri = java.net.URI.create(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(java.util.Locale.ROOT);
            return host.equals("youtube.com") || host.endsWith(".youtube.com")
                    || host.equals("youtu.be") || host.endsWith(".youtu.be");
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private void updateButtons() {
        if (this.playStopButton == null || this.loopButton == null) return;
        boolean playing = PlayMusicClient.MUSIC_PLAYER.isPlaying();
        boolean loop = PlayMusicClient.MUSIC_PLAYER.isLoopEnabled();
        this.playStopButton.setMessage(Text.literal(playing ? "Stop" : "Play"));
        this.loopButton.setMessage(Text.literal("Loop: " + (loop ? "ON" : "OFF")));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.urlField != null) this.urlField.tick();
        updateButtons();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        int left = (this.width - CARD_W) / 2;
        int top = (this.height - CARD_H) / 2;

        context.fill(left - 4, top - 4, left + CARD_W + 4, top + CARD_H + 4, 0xB0000000);
        context.fill(left, top, left + CARD_W, top + CARD_H, 0xE9141418);
        context.fill(left, top, left + CARD_W, top + 2, 0xFF6E7BFF);

        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("PlayMusic"),
                this.width / 2, top + 24, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("YouTube audio player"),
                this.width / 2, top + 43, 0xFFAAAAAA);

        context.drawTextWithShadow(this.textRenderer, Text.literal("YouTube URL"),
                left + 30, top + 58, 0xFFE0E0E0);

        String status = PlayMusicClient.MUSIC_PLAYER.getStatus();
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(status),
                this.width / 2, top + 187, 0xFFBBBBBB);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        this.client.setScreen(null);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
