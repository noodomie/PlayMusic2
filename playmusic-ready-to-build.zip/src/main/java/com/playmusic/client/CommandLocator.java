package com.playmusic.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

public final class CommandLocator {
    private CommandLocator() {}

    public record Tools(String ytDlp, String ffmpeg) {}

    public static Tools locate() {
        Properties properties = loadProperties();
        String yt = firstExistingExecutable(properties.getProperty("yt_dlp_path"), env("PLAYMUSIC_YTDLP"),
                localBin("yt-dlp"), localBin("yt-dlp.exe"), "yt-dlp", "yt-dlp.exe");
        String ffmpeg = firstExistingExecutable(properties.getProperty("ffmpeg_path"), env("PLAYMUSIC_FFMPEG"),
                localBin("ffmpeg"), localBin("ffmpeg.exe"), "ffmpeg", "ffmpeg.exe");
        return new Tools(yt, ffmpeg);
    }

    private static Properties loadProperties() {
        Properties p = new Properties();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("playmusic.properties");
        if (Files.isRegularFile(file)) {
            try (var in = Files.newInputStream(file)) {
                p.load(in);
            } catch (IOException ignored) {
            }
        }
        return p;
    }

    private static String env(String key) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? null : value;
    }

    private static String localBin(String name) {
        Path bin = FabricLoader.getInstance().getConfigDir().resolve("../playmusic/bin").normalize();
        Path candidate = bin.resolve(name);
        return Files.isRegularFile(candidate) ? candidate.toAbsolutePath().toString() : null;
    }

    private static String firstExistingExecutable(String... candidates) {
        for (String candidate : candidates) {
            if (candidate == null || candidate.isBlank()) continue;
            if (looksLikePath(candidate)) {
                Path p = Path.of(candidate);
                if (Files.isRegularFile(p)) return p.toAbsolutePath().toString();
                continue;
            }
            if (isOnPath(candidate)) return candidate;
        }
        return null;
    }

    private static boolean looksLikePath(String value) {
        return value.contains("/") || value.contains("\\") || value.endsWith(".exe") || value.endsWith(".py");
    }

    private static boolean isOnPath(String command) {
        String path = System.getenv("PATH");
        if (path == null) return false;
        String[] dirs = path.split(java.io.File.pathSeparator);
        for (String dir : dirs) {
            Path p = Path.of(dir, command);
            if (Files.isRegularFile(p)) return true;
            if (!command.toLowerCase(Locale.ROOT).endsWith(".exe")) {
                Path exe = Path.of(dir, command + ".exe");
                if (Files.isRegularFile(exe)) return true;
            }
        }
        return false;
    }
}
