package com.playmusic.client;

import net.fabricmc.loader.api.FabricLoader;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class MusicPlayer {
    private final ExecutorService executor = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "playmusic-worker");
        t.setDaemon(true);
        return t;
    });

    private final AtomicLong generation = new AtomicLong();
    private final AtomicBoolean loop = new AtomicBoolean(false);

    private volatile boolean playing;
    private volatile boolean downloading;
    private volatile String status = "Ready";
    private volatile Future<?> downloadFuture;
    private volatile Future<?> playbackFuture;
    private volatile Process downloadProcess;
    private volatile SourceDataLine activeLine;
    private volatile Path activeFile;

    public void setLoop(boolean enabled) {
        loop.set(enabled);
    }

    public boolean isLoopEnabled() {
        return loop.get();
    }

    public boolean isPlaying() {
        return playing;
    }

    public boolean isBusy() {
        return playing || downloading;
    }

    public String getStatus() {
        return status;
    }

    public synchronized void start(String url) {
        stopInternal(false);
        long id = generation.incrementAndGet();
        downloading = true;
        status = "Downloading audio...";

        downloadFuture = executor.submit(() -> downloadAndPlay(url, id));
    }

    public synchronized void stop() {
        generation.incrementAndGet();
        stopInternal(true);
        status = "Stopped";
    }

    private void stopInternal(boolean clearFile) {
        downloading = false;
        playing = false;

        Process process = downloadProcess;
        if (process != null) {
            try { process.destroyForcibly(); } catch (Exception ignored) {}
        }
        downloadProcess = null;

        Future<?> d = downloadFuture;
        if (d != null) d.cancel(true);
        downloadFuture = null;

        Future<?> p = playbackFuture;
        if (p != null) p.cancel(true);
        playbackFuture = null;

        SourceDataLine line = activeLine;
        if (line != null) {
            try {
                line.stop();
            } catch (Exception ignored) {}
            try {
                line.flush();
            } catch (Exception ignored) {}
            try {
                line.close();
            } catch (Exception ignored) {}
        }
        activeLine = null;

        Path file = activeFile;
        activeFile = null;
        if (clearFile && file != null) deleteQuietly(file);
    }

    private void downloadAndPlay(String url, long id) {
        Path file = null;
        try {
            CommandLocator.Tools tools = CommandLocator.locate();
            if (tools.ytDlp() == null) throw new IOException("yt-dlp was not found.");
            if (tools.ffmpeg() == null) throw new IOException("FFmpeg was not found.");

            Path cacheDir = FabricLoader.getInstance().getConfigDir().resolve("playmusic-cache");
            Files.createDirectories(cacheDir);
            file = cacheDir.resolve("track-" + id + ".wav");
            activeFile = file;

            List<String> command = new java.util.ArrayList<>();
            command.add(tools.ytDlp());
            command.add("--no-playlist");
            command.add("--no-part");
            command.add("--no-warnings");
            command.add("--quiet");
            command.add("-x");
            command.add("--audio-format");
            command.add("wav");
            command.add("--ffmpeg-location");
            command.add(tools.ffmpeg());
            command.add("-o");
            command.add(file.toString());
            command.add(url);

            Process process = new ProcessBuilder(command)
                    .redirectErrorStream(true)
                    .start();
            downloadProcess = process;

            process.getInputStream().transferTo(java.io.OutputStream.nullOutputStream());
            int exitCode = process.waitFor();
            downloadProcess = null;

            if (id != generation.get()) {
                deleteQuietly(file);
                return;
            }
            if (exitCode != 0 || !Files.isRegularFile(file) || Files.size(file) < 44) {
                throw new IOException("YouTube audio download failed.");
            }

            downloading = false;
            status = "Starting playback...";
            playbackFuture = executor.submit(() -> streamAudio(file, id));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (id == generation.get()) status = "Stopped";
            if (file != null) deleteQuietly(file);
        } catch (Exception e) {
            downloading = false;
            playing = false;
            deleteQuietly(file);
            if (id == generation.get()) {
                String message = e.getMessage() == null ? "Playback failed." : e.getMessage();
                status = message;
                PlayMusicClient.showError(message);
            }
        }
    }

    private void streamAudio(Path file, long id) {
        playing = true;
        status = "Playing";
        try {
            do {
                if (id != generation.get() || Thread.currentThread().isInterrupted()) return;
                playOnePass(file, id);
            } while (loop.get() && id == generation.get() && !Thread.currentThread().isInterrupted());

            if (id == generation.get()) {
                playing = false;
                status = "Finished";
            }
        } catch (Exception e) {
            if (id == generation.get()) {
                playing = false;
                status = "Audio playback failed.";
                PlayMusicClient.showError(status + " " + e.getMessage());
            }
        } finally {
            SourceDataLine line = activeLine;
            activeLine = null;
            if (line != null) {
                try { line.close(); } catch (Exception ignored) {}
            }
            if (id == generation.get()) {
                Path current = activeFile;
                activeFile = null;
                deleteQuietly(current);
            } else {
                deleteQuietly(file);
            }
        }
    }

    private void playOnePass(Path file, long id) throws Exception {
        try (AudioInputStream source = AudioSystem.getAudioInputStream(file)) {
            AudioFormat base = source.getFormat();
            AudioFormat decoded = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    base.getSampleRate(),
                    16,
                    base.getChannels(),
                    base.getChannels() * 2,
                    base.getSampleRate(),
                    false
            );

            try (AudioInputStream pcm = AudioSystem.getAudioInputStream(decoded, source)) {
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, decoded);
                SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
                activeLine = line;
                line.open(decoded);
                line.start();

                byte[] buffer = new byte[16 * 1024];
                int read;
                while ((read = pcm.read(buffer)) != -1) {
                    if (id != generation.get() || Thread.currentThread().isInterrupted()) break;
                    line.write(buffer, 0, read);
                }
                line.drain();
                line.stop();
                line.close();
                activeLine = null;
            }
        }
    }

    private static void deleteQuietly(Path file) {
        if (file == null) return;
        try { Files.deleteIfExists(file); } catch (IOException ignored) {}
    }
}
