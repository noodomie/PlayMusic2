package com.playmusic.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class PlayMusicClient implements ClientModInitializer {
    public static final String MOD_ID = "playmusic";
    public static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.playmusic.open_menu",
                GLFW.GLFW_KEY_O,
                "category.playmusic"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new MusicScreen());
                } else if (client.currentScreen instanceof MusicScreen) {
                    client.setScreen(null);
                }
            }
        });
    }

    public static void showError(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            if (client.player != null) {
                client.player.sendMessage(Text.literal("[PlayMusic] " + message), false);
            }
        });
    }
}
